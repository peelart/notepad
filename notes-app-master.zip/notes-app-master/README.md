
## Cloning and starting application
1. - git clone https://github.com/divanov11/notes-app
1. - cd notes-app
2. - npm install
3. - npm run server //STARTS JSON SERVER ON PORT 5000
4. - npm start  //STARTS REACT SERVER


# Notes List
<img src="./Notes.PNG">  

